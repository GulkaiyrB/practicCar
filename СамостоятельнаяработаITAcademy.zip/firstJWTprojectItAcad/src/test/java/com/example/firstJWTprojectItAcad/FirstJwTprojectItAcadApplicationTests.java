package com.example.firstJWTprojectItAcad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstJwTprojectItAcadApplicationTests {

	@Test
	void contextLoads() {
	}

}
